import PizzaStore from "@/components/PizzaStore"

export default function Home() {
  return <PizzaStore />
}

